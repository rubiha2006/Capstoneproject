import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker_web/image_picker_web.dart';
import 'package:mime/mime.dart';
import 'package:http_parser/http_parser.dart';
import 'package:translator/translator.dart';

import 'community_form.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PlantDoc AI',
      theme: ThemeData(
        primarySwatch: Colors.green,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const PlantDiseaseScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class PlantDiseaseScreen extends StatefulWidget {
  const PlantDiseaseScreen({super.key});

  @override
  State<PlantDiseaseScreen> createState() => _PlantDiseaseScreenState();
}

class _PlantDiseaseScreenState extends State<PlantDiseaseScreen> {
  String? _imageUrl;
  bool _isLoading = false;
  Map<String, dynamic>? _diagnosisResult;
  String? _error;
  bool _offlineMode = false;
  final List<Map<String, dynamic>> _history = [];
  String _selectedLanguage = 'en';
  final translator = GoogleTranslator();
  final Map<String, String> _languageNames = {
    'en': 'English',
    'es': 'Español',
    'fr': 'Français',
    'de': 'Deutsch',
    'hi': 'हिन्दी',
    'ar': 'العربية',
    'zh': '中文',
    'ja': '日本語',
    'ru': 'Русский',
    'pt': 'Português',
  };

  Future<String> _translate(String text, {String? to}) async {
    if (_selectedLanguage == 'en') return text;
    try {
      final translation = await translator.translate(
        text,
        to: to ?? _selectedLanguage,
      );
      return translation.text;
    } catch (e) {
      print('Translation error: $e');
      return text; // Return original text if translation fails
    }
  }

  Future<Map<String, dynamic>> _translateDiagnosis(
    Map<String, dynamic> result,
  ) async {
    final translated = Map<String, dynamic>.from(result);

    // Translate disease name
    translated['disease'] = await _translate(result['disease']);

    // Translate disease description if exists
    if (result['description'] != null) {
      translated['description'] = await _translate(result['description']);
    }

    // Translate recommendations
    if (result['recommendations'] != null) {
      final translatedRecs = <String>[];
      for (var rec in result['recommendations']) {
        translatedRecs.add(await _translate(rec));
      }
      translated['recommendations'] = translatedRecs;
    }

    return translated;
  }

  Future<Map<String, dynamic>> _analyzeOnline(
    Uint8List imageBytes,
    String fileName,
  ) async {
    try {
      final uri = Uri.parse('http://127.0.0.1:5000/predict');
      var request = http.MultipartRequest('POST', uri);

      // Add the image file
      request.files.add(
        http.MultipartFile.fromBytes('file', imageBytes, filename: fileName),
      );

      // Send the request
      final response = await request.send();
      final responseBody = await response.stream.bytesToString();

      if (response.statusCode != 200) {
        throw Exception('Server error: ${response.statusCode} - $responseBody');
      }

      final result = jsonDecode(responseBody) as Map<String, dynamic>;

      // Get additional disease information
      try {
        final infoUri = Uri.parse(
          'http://127.0.0.1:5000/disease_info/${result['disease']}',
        );
        final infoResponse = await http.get(infoUri);
        if (infoResponse.statusCode == 200) {
          final infoData = jsonDecode(infoResponse.body);
          result['description'] = _generateDiseaseDescription(
            infoData['treatments'],
          );
        }
      } catch (e) {
        print('Failed to fetch disease info: $e');
      }

      return result;
    } catch (e) {
      print('Error in _analyzeOnline: $e');
      rethrow;
    }
  }

  Future<void> _analyzeImage(Uint8List imageBytes, String fileName) async {
    setState(() {
      _isLoading = true;
      _error = null;
      _offlineMode = false;
    });

    try {
      // Try online analysis first
      final onlineResult = await _analyzeOnline(imageBytes, fileName);
      final translatedResult = await _translateDiagnosis(onlineResult);
      _saveToHistory(translatedResult);

      setState(() {
        _diagnosisResult = translatedResult;
        _imageUrl = 'data:image/jpeg;base64,${base64Encode(imageBytes)}';
      });
    } catch (e) {
      print('Online analysis failed: $e');
      // Fallback to offline analysis
      try {
        final offlineResult = await _analyzeOffline(imageBytes);
        final translatedResult = await _translateDiagnosis(offlineResult);
        _saveToHistory(translatedResult);

        setState(() {
          _diagnosisResult = translatedResult;
          _imageUrl = 'data:image/jpeg;base64,${base64Encode(imageBytes)}';
          _offlineMode = true;
          _error =
              'Online analysis failed. Using offline mode with limited accuracy.';
        });
      } catch (offlineError) {
        setState(() {
          _error = 'Failed to analyze image: ${e.toString()}';
        });
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  String _generateDiseaseDescription(List<dynamic> treatments) {
    if (treatments.isEmpty) return 'No additional information available.';

    // Take the first treatment as the main description
    String firstTreatment = treatments[0].toString();

    // If the treatment is long, summarize it
    if (firstTreatment.length > 100) {
      firstTreatment = firstTreatment.substring(0, 100) + '...';
    }

    return firstTreatment;
  }

  Future<Map<String, dynamic>> _analyzeOffline(Uint8List imageBytes) async {
    // Simplified offline analysis (would use TensorFlow Lite in production)
    await Future.delayed(const Duration(seconds: 1)); // Simulate processing

    return {
      'disease': 'Possible Disease (Offline)',
      'confidence': 0.75,
      'timestamp': DateTime.now().toIso8601String(),
      'description':
          'General plant disease detected. For accurate diagnosis, please connect to the internet.',
      'recommendations': [
        'Isolate affected plants',
        'Apply general fungicide',
        'Monitor plant health',
      ],
      'offline': true,
    };
  }

  void _saveToHistory(Map<String, dynamic> result) {
    setState(() {
      _history.insert(0, {
        ...result,
        'image': _imageUrl,
        'date': DateTime.now().toIso8601String(),
      });
    });
  }

  Future<void> _pickImage() async {
    try {
      final image = await ImagePickerWeb.getImageAsBytes();
      if (image == null) return;

      await _analyzeImage(image, 'plant_image.jpg');
    } catch (e) {
      setState(() => _error = 'Image selection failed: ${e.toString()}');
    }
  }

  Widget _buildDiagnosisReport() {
    if (_diagnosisResult == null) return Container();

    return Card(
      elevation: 4,
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            FutureBuilder<String>(
              future: _translate('Plant Disease Diagnosis'),
              builder: (context, snapshot) {
                return Text(
                  snapshot.data ?? 'Plant Disease Diagnosis',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    color: Colors.green[800],
                    fontWeight: FontWeight.bold,
                  ),
                );
              },
            ),
            const SizedBox(height: 16),

            // Disease Information Section
            FutureBuilder<String>(
              future: _translate('Disease Information'),
              builder: (context, snapshot) {
                return Text(
                  snapshot.data ?? 'Disease Information',
                  style: Theme.of(
                    context,
                  ).textTheme.titleLarge?.copyWith(color: Colors.green[700]),
                );
              },
            ),
            const SizedBox(height: 8),
            _buildReportItem(
              'Identified Disease',
              _diagnosisResult!['disease'] ?? 'Unknown',
              icon: Icons.health_and_safety,
            ),
            _buildReportItem(
              'Confidence Level',
              '${((_diagnosisResult!['confidence'] ?? 0) * 100).toStringAsFixed(1)}%',
              icon: Icons.assessment,
            ),
            if (_diagnosisResult!['description'] != null)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    FutureBuilder<String>(
                      future: _translate('Description'),
                      builder: (context, snapshot) {
                        return Text(
                          '${snapshot.data ?? 'Description'}:',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        );
                      },
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _diagnosisResult!['description'],
                      style: const TextStyle(color: Colors.black87),
                    ),
                  ],
                ),
              ),
            if (_diagnosisResult!['timestamp'] != null)
              _buildReportItem(
                'Analysis Date',
                _formatDate(_diagnosisResult!['timestamp']),
                icon: Icons.calendar_today,
              ),
            if (_offlineMode)
              _buildReportItem(
                'Analysis Mode',
                'Offline (Limited Accuracy)',
                icon: Icons.offline_bolt,
              ),
            const Divider(height: 24, thickness: 1),

            // Treatment Recommendations Section
            FutureBuilder<String>(
              future: _translate('Treatment Recommendations'),
              builder: (context, snapshot) {
                return Text(
                  snapshot.data ?? 'Treatment Recommendations',
                  style: Theme.of(
                    context,
                  ).textTheme.titleLarge?.copyWith(color: Colors.green[700]),
                );
              },
            ),
            const SizedBox(height: 8),
            if (_diagnosisResult!['recommendations'] != null &&
                (_diagnosisResult!['recommendations'] as List).isNotEmpty)
              ...(_diagnosisResult!['recommendations'] as List).map(
                (recommendation) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(top: 4.0, right: 8.0),
                        child: Icon(Icons.medical_services, size: 16),
                      ),
                      Expanded(
                        child: Text(
                          recommendation.toString(),
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ),
                    ],
                  ),
                ),
              )
            else
              FutureBuilder<String>(
                future: _translate('No specific recommendations available'),
                builder: (context, snapshot) {
                  return Text(
                    snapshot.data ?? 'No specific recommendations available',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      fontStyle: FontStyle.italic,
                    ),
                  );
                },
              ),
            const Divider(height: 24, thickness: 1),
            Row(
              children: [
                Expanded(
                  child: FutureBuilder<String>(
                    future: _translate('Save Report'),
                    builder: (context, snapshot) {
                      return OutlinedButton.icon(
                        icon: const Icon(Icons.save),
                        label: Text(snapshot.data ?? 'Save Report'),
                        onPressed: () => _saveReport(),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FutureBuilder<String>(
                    future: _translate('Share'),
                    builder: (context, snapshot) {
                      return ElevatedButton.icon(
                        icon: const Icon(Icons.share),
                        label: Text(snapshot.data ?? 'Share'),
                        onPressed: () => _shareToCommunity(_diagnosisResult!),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue[700],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: FutureBuilder<String>(
                    future: _translate('Expert Consultation'),
                    builder: (context, snapshot) {
                      return ElevatedButton.icon(
                        icon: const Icon(Icons.medical_services),
                        label: Text(snapshot.data ?? 'Expert Consultation'),
                        onPressed: () => _showExpertConsultation(),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green[700],
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReportItem(String label, String value, {IconData? icon}) {
    return FutureBuilder<String>(
      future: _translate(label),
      builder: (context, snapshot) {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Row(
            children: [
              if (icon != null)
                Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: Icon(icon, size: 20, color: Colors.green[700]),
                ),
              Expanded(
                flex: 2,
                child: Text(
                  '${snapshot.data ?? label}:',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              Expanded(
                flex: 3,
                child: Text(
                  value,
                  style: const TextStyle(color: Colors.black87),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  String _formatDate(String isoDate) {
    try {
      final date = DateTime.parse(isoDate);
      return '${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
    } catch (e) {
      return isoDate;
    }
  }

  void _saveReport() async {
    if (_diagnosisResult == null || _imageUrl == null) return;

    try {
      // In a real app, you would save this to local storage or a database
      // For now, we'll just show a confirmation message
      final message = await _translate('Report saved successfully');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message), duration: const Duration(seconds: 2)),
      );
    } catch (e) {
      final errorMessage = await _translate('Failed to save report');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('$errorMessage: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _showExpertConsultation() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: FutureBuilder<String>(
          future: _translate('Expert Consultation'),
          builder: (context, snapshot) {
            return Text(snapshot.data ?? 'Expert Consultation');
          },
        ),
        content: FutureBuilder<String>(
          future: _translate(
            'Connect with our plant health experts for personalized advice.',
          ),
          builder: (context, snapshot) {
            return Text(
              snapshot.data ??
                  'Connect with our plant health experts for personalized advice.',
            );
          },
        ),
        actions: [
          FutureBuilder<String>(
            future: _translate('Later'),
            builder: (context, snapshot) {
              return TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(snapshot.data ?? 'Later'),
              );
            },
          ),
          FutureBuilder<String>(
            future: _translate('Request Now'),
            builder: (context, snapshot) {
              return ElevatedButton(
                onPressed: () async {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        await _translate('Consultation request sent'),
                      ),
                    ),
                  );
                },
                child: Text(snapshot.data ?? 'Request Now'),
              );
            },
          ),
        ],
      ),
    );
  }

  Future<void> _shareToCommunity(Map<String, dynamic> diagnosis) async {
    try {
      final result = diagnosis ?? _diagnosisResult;
      if (result == null) return;

      final shouldShare = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: FutureBuilder<String>(
            future: _translate('Share to Community'),
            builder: (context, snapshot) {
              return Text(snapshot.data ?? 'Share to Community');
            },
          ),
          content: FutureBuilder<String>(
            future: _translate(
              'Do you want to share this diagnosis with the community?',
            ),
            builder: (context, snapshot) {
              return Text(
                snapshot.data ??
                    'Do you want to share this diagnosis with the community?',
              );
            },
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: FutureBuilder<String>(
                future: _translate('Cancel'),
                builder: (context, snapshot) {
                  return Text(snapshot.data ?? 'Cancel');
                },
              ),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: FutureBuilder<String>(
                future: _translate('Share'),
                builder: (context, snapshot) {
                  return Text(snapshot.data ?? 'Share');
                },
              ),
            ),
          ],
        ),
      );

      if (shouldShare != true) return;

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => CommunityForumScreen(
            preFilledData: {
              'plantName': result['disease']?.split(' ').first ?? 'Plant',
              'disease': result['disease'] ?? 'Unknown Disease',
              'confidence': result['confidence'] ?? 0.0,
              'imageUrl': _imageUrl ?? '',
              'recommendations':
                  result['recommendations']?.join(', ') ?? 'No recommendations',
            },
          ),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            await _translate('Failed to share: ${e.toString()}') ??
                'Failed to share',
          ),
        ),
      );
    }
  }

  void _openCommunityForum() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const CommunityForumScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: FutureBuilder<String>(
          future: _translate('PlantDoc AI'),
          builder: (context, snapshot) {
            return Text(snapshot.data ?? 'PlantDoc AI');
          },
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.history),
            onPressed: () => _showHistory(),
          ),
          IconButton(
            icon: const Icon(Icons.language),
            onPressed: () => _changeLanguage(),
          ),
        ],
      ),
      drawer: _buildNavigationDrawer(),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  if (_error != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 16.0),
                      child: Text(
                        _error!,
                        style: TextStyle(color: Colors.red[700]),
                      ),
                    ),
                  _buildImageSection(),
                  const SizedBox(height: 24),
                  if (_diagnosisResult != null) _buildDiagnosisReport(),
                  if (_offlineMode)
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: FutureBuilder<String>(
                        future: _translate(
                          'Offline mode - results may be less accurate',
                        ),
                        builder: (context, snapshot) {
                          return Text(
                            snapshot.data ??
                                'Offline mode - results may be less accurate',
                            style: TextStyle(color: Colors.orange[700]),
                          );
                        },
                      ),
                    ),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _pickImage,
        tooltip: 'Analyze Plant',
        child: const Icon(Icons.camera_alt),
      ),
    );
  }

  Widget _buildImageSection() {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              height: 250,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(8),
              ),
              child: _imageUrl == null
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.photo_camera, size: 50),
                        const SizedBox(height: 16),
                        FutureBuilder<String>(
                          future: _translate('No plant image selected'),
                          builder: (context, snapshot) {
                            return Text(
                              snapshot.data ?? 'No plant image selected',
                              style: Theme.of(context).textTheme.bodyLarge,
                            );
                          },
                        ),
                      ],
                    )
                  : Image.network(_imageUrl!, fit: BoxFit.cover),
            ),
            const SizedBox(height: 16),
            FutureBuilder<String>(
              future: _translate('Select Plant Image'),
              builder: (context, snapshot) {
                return ElevatedButton(
                  onPressed: _pickImage,
                  child: Text(snapshot.data ?? 'Select Plant Image'),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavigationDrawer() {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: const BoxDecoration(color: Colors.green),
            child: FutureBuilder<String>(
              future: _translate('PlantDoc AI'),
              builder: (context, snapshot) {
                return Text(
                  snapshot.data ?? 'PlantDoc AI',
                  style: const TextStyle(color: Colors.white, fontSize: 24),
                );
              },
            ),
          ),
          ListTile(
            leading: const Icon(Icons.home),
            title: FutureBuilder<String>(
              future: _translate('Home'),
              builder: (context, snapshot) {
                return Text(snapshot.data ?? 'Home');
              },
            ),
            onTap: () => Navigator.pop(context),
          ),
          ListTile(
            leading: const Icon(Icons.history),
            title: FutureBuilder<String>(
              future: _translate('Analysis History'),
              builder: (context, snapshot) {
                return Text(snapshot.data ?? 'Analysis History');
              },
            ),
            onTap: () {
              Navigator.pop(context);
              _showHistory();
            },
          ),
          ListTile(
            leading: const Icon(Icons.people),
            title: FutureBuilder<String>(
              future: _translate('Community Forum'),
              builder: (context, snapshot) {
                return Text(snapshot.data ?? 'Community Forum');
              },
            ),
            onTap: () {
              Navigator.pop(context);
              _openCommunityForum();
            },
          ),
          ListTile(
            leading: const Icon(Icons.settings),
            title: FutureBuilder<String>(
              future: _translate('Settings'),
              builder: (context, snapshot) {
                return Text(snapshot.data ?? 'Settings');
              },
            ),
            onTap: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }

  void _showHistory() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: FutureBuilder<String>(
          future: _translate('Analysis History'),
          builder: (context, snapshot) {
            return Text(snapshot.data ?? 'Analysis History');
          },
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: _history.length,
            itemBuilder: (context, index) {
              final item = _history[index];
              return ListTile(
                leading: item['image'] != null
                    ? Image.network(item['image'], width: 50, height: 50)
                    : const Icon(Icons.image),
                title: Text(item['disease']),
                subtitle: Text(
                  '${(item['confidence'] * 100).toStringAsFixed(1)}% - ${_formatDate(item['date'])}',
                ),
                onTap: () {
                  setState(() {
                    _diagnosisResult = item;
                    _imageUrl = item['image'];
                  });
                  Navigator.pop(context);
                },
              );
            },
          ),
        ),
        actions: [
          FutureBuilder<String>(
            future: _translate('Close'),
            builder: (context, snapshot) {
              return TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(snapshot.data ?? 'Close'),
              );
            },
          ),
        ],
      ),
    );
  }

  void _changeLanguage() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: FutureBuilder<String>(
          future: _translate('Select Language'),
          builder: (context, snapshot) {
            return Text(snapshot.data ?? 'Select Language');
          },
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: _languageNames.entries.map((entry) {
            return ListTile(
              title: Text(entry.value),
              leading: Radio(
                value: entry.key,
                groupValue: _selectedLanguage,
                onChanged: (value) async {
                  if (value != null) {
                    setState(() => _selectedLanguage = value);
                    Navigator.pop(context);

                    if (_diagnosisResult != null) {
                      setState(() => _isLoading = true);
                      final translated = await _translateDiagnosis(
                        _diagnosisResult!,
                      );
                      setState(() {
                        _diagnosisResult = translated;
                        _isLoading = false;
                      });
                    }
                  }
                },
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
